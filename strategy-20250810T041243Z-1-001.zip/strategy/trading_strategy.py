# strategy/trading_strategy.py

import pandas as pd
import logging
from strategy.indicators import calculate_rsi, calculate_sma
from config import settings # Import settings module directly

logger = logging.getLogger(__name__)

class TradingStrategy:
    def __init__(self):
        self.rsi_period = settings.RSI_PERIOD
        self.rsi_buy_threshold = settings.RSI_BUY_THRESHOLD
        self.short_ma_period = settings.SHORT_MA_PERIOD
        self.long_ma_period = settings.LONG_MA_PERIOD

    def generate_signals(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Generates buy/sell signals based on RSI and Moving Average Crossover strategy.
        Adds 'RSI', 'SMA_short', 'SMA_long', 'Signal' (1=Buy, -1=Sell, 0=Hold), and 'Position' columns.
        Parameters:
            df (pd.DataFrame): DataFrame with historical OHLCV data.
        Returns:
            pd.DataFrame: DataFrame with added indicator, signal, and position columns.
        """
        if df.empty:
            logger.warning("Empty DataFrame provided to generate_signals.")
            return df

        # Calculate indicators
        df['RSI'] = calculate_rsi(df, self.rsi_period)
        df[f'SMA_{self.short_ma_period}'] = calculate_sma(df, self.short_ma_period)
        df[f'SMA_{self.long_ma_period}'] = calculate_sma(df, self.long_ma_period)

        df['Signal'] = 0 # Default to hold signal
        df['Position'] = 0 # 1 for Long, 0 for Flat (no position)

        # Drop NaN values introduced by indicator calculations before generating signals
        df.dropna(subset=['RSI', f'SMA_{self.short_ma_period}', f'SMA_{self.long_ma_period}'], inplace=True)
        if df.empty:
            logger.warning("DataFrame became empty after dropping NaNs for indicator calculations.")
            return df

        # Buy condition: RSI < 30 AND 20-DMA crosses above 50-DMA
        # Check current day's MA relationship and previous day's relationship for a crossover
        buy_condition = (df['RSI'] < self.rsi_buy_threshold) & \
                        (df[f'SMA_{self.short_ma_period}'] > df[f'SMA_{self.long_ma_period}']) & \
                        (df[f'SMA_{self.short_ma_period}'].shift(1) <= df[f'SMA_{self.long_ma_period}'].shift(1))

        # Sell condition: 20-DMA crosses below 50-DMA (as a simple exit)
        sell_condition = (df[f'SMA_{self.short_ma_period}'] < df[f'SMA_{self.long_ma_period}']) & \
                         (df[f'SMA_{self.short_ma_period}'].shift(1) >= df[f'SMA_{self.long_ma_period}'].shift(1))

        # Apply signals
        df.loc[buy_condition, 'Signal'] = 1
        df.loc[sell_condition, 'Signal'] = -1

        # Determine position based on signals
        # This simulates opening a position on a buy signal and closing on a sell signal.
        # It's a simplified approach for backtesting.
        current_position = 0
        position_list = []
        for i in range(len(df)):
            if df['Signal'].iloc[i] == 1: # Buy signal
                current_position = 1 # Go long
            elif df['Signal'].iloc[i] == -1: # Sell signal
                current_position = 0 # Close position (go flat)
            position_list.append(current_position)

        df['Position'] = position_list
        logger.info("Signals generated successfully.")
        return df
