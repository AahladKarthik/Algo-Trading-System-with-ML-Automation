# strategy/indicators.py

import pandas as pd
import ta # Technical Analysis library

def calculate_rsi(df: pd.DataFrame, window: int = 14) -> pd.Series:
    """
    Calculates Relative Strength Index (RSI).
    Parameters:
        df (pd.DataFrame): DataFrame with 'Close' prices.
        window (int): The window period for RSI calculation.
    Returns:
        pd.Series: A Series containing RSI values.
    """
    return ta.momentum.RSIIndicator(df["Close"].squeeze(), window=window).rsi()

def calculate_sma(df: pd.DataFrame, window: int) -> pd.Series:
    """
    Calculates Simple Moving Average (SMA).
    Parameters:
        df (pd.DataFrame): DataFrame with 'Close' prices.
        window (int): The window period for SMA calculation.
    Returns:
        pd.Series: A Series containing SMA values.
    """
    return ta.trend.SMAIndicator(df["Close"], window=window).sma_indicator()

def calculate_macd(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculates Moving Average Convergence Divergence (MACD), Signal Line, and MACD Histogram.
    Parameters:
        df (pd.DataFrame): DataFrame with 'Close' prices.
    Returns:
        pd.DataFrame: DataFrame with 'MACD', 'MACD_Signal', and 'MACD_Hist' columns.
    """
    # Fixed: Ensure df["Close"] is explicitly a Series using .squeeze()
    macd_indicator = ta.trend.MACD(df["Close"].squeeze()) # <<< ADD .squeeze() here
    return pd.DataFrame({
        'MACD': macd_indicator.macd(),
        'MACD_Signal': macd_indicator.macd_signal(),
        'MACD_Hist': macd_indicator.macd_diff()
    })
