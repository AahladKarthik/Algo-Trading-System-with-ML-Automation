# analytics/ml_predictor.py

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
import logging
from strategy.indicators import calculate_rsi, calculate_macd
from config import settings

logger = logging.getLogger(__name__)

class MLPredictor:
    def __init__(self, model_type: str = 'decision_tree'):
        """
        Initializes the ML Predictor with a specified model type.
        Parameters:
            model_type (str): 'decision_tree' or 'logistic_regression'.
        """
        if model_type == 'decision_tree':
            self.model = DecisionTreeClassifier(random_state=42)
        elif model_type == 'logistic_regression':
            self.model = LogisticRegression(random_state=42, solver='liblinear')
        else:
            raise ValueError("Unsupported model_type. Choose 'decision_tree' or 'logistic_regression'.")
        self.trained = False # Flag to check if model has been trained


    def prepare_data_for_ml(self, df: pd.DataFrame) -> pd.DataFrame:
        # Calculate features
        df['RSI'] = calculate_rsi(df, window=settings.RSI_PERIOD)
        # Ensure MACD df has a matching index to the main df before merging
        macd_df = calculate_macd(df)

        # Use pd.merge on the index (which is 'Date')
        # Assuming both df and macd_df have a clean DatetimeIndex
        df = pd.merge(df, macd_df, left_index=True, right_index=True, how='inner') # Use inner to keep only common dates


        # Calculate next-day close movement as target (1 for Up, 0 for Down/No Change)
        # Shift(-1) means the close price of the *next* row
        df['Next_Day_Close'] = df['Close'].shift(-1)
        # Target: 1 if next day's close is higher, 0 otherwise
        df['Next_Day_Movement'] = (df['Next_Day_Close'] > df['Close']).astype(int)

        # Drop rows with NaN values (due to indicator calculation or Next_Day_Close for last row)
        df.dropna(subset=settings.FEATURES + ['Next_Day_Movement'], inplace=True)
        return df

    def train_model(self, df: pd.DataFrame, features: list, target: str):
        """
        Trains the ML model and evaluates its performance.
        Parameters:
            df (pd.DataFrame): Prepared DataFrame with features and target.
            features (list): List of column names to use as features.
            target (str): Name of the target column.
        Returns:
            tuple: (accuracy, classification_report_string). Returns (0.0, "") if training fails.
        """
        if df.empty or not all(col in df.columns for col in features + [target]):
            logger.warning("Insufficient data or missing columns for ML training.")
            self.trained = False
            return 0.0, ""

        X = df[features]
        y = df[target]

        # Handle cases where only one class is present in the target variable
        if len(y.unique()) < 2:
            logger.warning(f"Only one class present in target variable for ML training (symbol has no 'Up' or 'Down' movements in data). Skipping training.")
            self.trained = False
            return 0.0, "Only one class in target"

        try:
            # Stratify ensures that the train/test split maintains the proportion of classes
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
        except ValueError as e:
            logger.warning(f"Could not split data for ML training due to: {e}. Check data balance or size.")
            self.trained = False
            return 0.0, str(e)

        self.model.fit(X_train, y_train)
        y_pred = self.model.predict(X_test)

        accuracy = accuracy_score(y_test, y_pred)
        # zero_division=0 prevents warnings when a class has no predicted samples
        report = classification_report(y_test, y_pred, zero_division=0)

        logger.info(f"ML Model Training Complete (Model: {type(self.model).__name__}):")
        logger.info(f"Accuracy: {accuracy:.4f}")
        logger.info(f"Classification Report:\n{report}")
        self.trained = True
        return accuracy, report

    def predict_next_day_movement(self, latest_data_df: pd.DataFrame, features: list) -> int:
        """
        Predicts the next day's movement (1 for Up, 0 for Down/No Change) based on the trained model.
        `latest_data_df` should contain enough historical rows to calculate required indicators
        for the *last* data point.
        Parameters:
            latest_data_df (pd.DataFrame): DataFrame containing recent historical OHLCV data.
                                           Should include enough rows to calculate all features.
            features (list): List of feature column names used during training.
        Returns:
            int: 1 for 'Up', 0 for 'Down/No Change', -1 if prediction cannot be made (e.g., not trained, no data).
        """
        if not self.trained:
            logger.warning("ML model is not trained. Cannot make prediction.")
            return -1

        if latest_data_df.empty:
            logger.warning("Empty DataFrame provided for ML prediction.")
            return -1

        # Prepare the data to get the latest features, similar to training data prep
        processed_df = self.prepare_data_for_ml(latest_data_df.copy())
        if processed_df.empty:
            logger.warning("Could not process latest data for prediction after feature engineering.")
            return -1

        # The last row of `processed_df` contains the latest calculated features
        # and its 'Next_Day_Movement' would be NaN (which is fine for prediction input)
        try:
            latest_features_row = processed_df[features].iloc[-1]
            # Reshape for prediction (sklearn expects 2D array, even for a single sample)
            prediction_input = latest_features_row.to_frame().T
            prediction = self.model.predict(prediction_input)[0]
            logger.info(f"Next day movement prediction: {'Up' if prediction == 1 else 'Down/No Change'}")
            return int(prediction) # You had a stray comment/code here, moved this line up
        except IndexError:
            logger.warning("Not enough data points in processed_df for prediction after feature engineering.")
            return -1
        except KeyError as e:
            logger.warning(f"Missing feature for prediction: {e}. Check FEATURES in settings.py and data preparation.")
            return -1
