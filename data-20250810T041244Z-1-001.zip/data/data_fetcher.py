# data/data_fetcher.py
import yfinance as yf
import pandas as pd
import logging
from datetime import datetime, timedelta
from config import settings

logger = logging.getLogger(__name__)

class DataFetcher:
    def __init__(self):
        pass

    def fetch_historical_data(self, symbol: str, start_date: str, end_date: str) -> pd.DataFrame:
        try:
            df = yf.download(symbol, start=start_date, end=end_date, progress=False)
            if df.empty:
                logger.warning(f"No data fetched for {symbol} between {start_date} and {end_date}.")
                return pd.DataFrame()

            # Ensure index is a clean DatetimeIndex and named 'Date'
            df.index = pd.to_datetime(df.index)
            df.index.name = 'Date'

            # --- CRITICAL FIX FOR YFINANCE COLUMNS (Revised) ---
            # Step 1: Flatten MultiIndex columns if they exist.
            # This is common, and the format is usually ('ColumnName', 'SymbolSuffix') or ('ColumnName', '')
            if isinstance(df.columns, pd.MultiIndex):
                # We want just 'Open', 'High', 'Low', 'Close', 'Volume', 'Adj Close'
                # Let's extract the first level of the MultiIndex or the full string if it's not a tuple
                new_columns = []
                for col in df.columns:
                    if isinstance(col, tuple):
                        # Take the main part (e.g., 'Close' from ('Close', 'RELIANCE.NS'))
                        new_columns.append(col[0].strip())
                    else:
                        new_columns.append(col.strip())
                df.columns = new_columns
                logger.info(f"Flattened MultiIndex columns for {symbol}. Raw flattened columns: {df.columns.tolist()}")

            # Step 2: Standardize column names and handle 'Adj Close'
            # Convert all column names to standard format (e.g., 'Open', 'Close')
            # Use .str.capitalize() on a Series of column names to handle variations like 'open' -> 'Open'
            df.columns = df.columns.str.replace(' ', '').str.capitalize() # Remove spaces, then capitalize (e.g., "Adj Close" -> "AdjClose" -> "Adjclose")

            # Check for 'Adj Close' (which would now be 'Adjclose' or 'AdjClose')
            if 'Adjclose' in df.columns:
                df['Close'] = df['Adjclose'] # Use Adjusted Close as the primary 'Close'
                df.drop(columns=['Adjclose'], inplace=True)
                logger.info(f"Used 'Adjclose' as 'Close' for {symbol}.")
            elif 'Close' not in df.columns:
                 logger.error(f"Neither 'Close' nor 'Adjclose' found for {symbol}. Available: {df.columns.tolist()}")
                 return pd.DataFrame()


            # Ensure only the desired columns are present and in order
            required_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
            if not all(col in df.columns for col in required_columns):
                missing = [col for col in required_columns if col not in df.columns]
                logger.error(f"Missing one or more critical columns ({missing}) after standardization for {symbol}. Available: {df.columns.tolist()}")
                return pd.DataFrame()

            df = df[required_columns] # Select the columns in the desired order

            logger.info(f"Successfully fetched and prepared historical data for {symbol}. Final columns: {df.columns.tolist()}")
            return df
        except Exception as e:
            logger.error(f"Error fetching data for {symbol} using yfinance: {e}")
            return pd.DataFrame()

# This function must have ZERO indentation
def get_historical_data(symbols: list, duration_months: int) -> dict:
    """
    Fetches historical data for multiple symbols for the last 'duration_months' using yfinance.
    Parameters:
        symbols (list): List of stock ticker symbols.
        duration_months (int): Number of months for which to fetch historical data.
    Returns:
        dict: A dictionary where keys are symbols and values are pandas DataFrames.
    """
    data_fetcher = DataFetcher()
    all_data = {}
    end_date = datetime.now()
    start_date = end_date - timedelta(days=duration_months * 30)

    start_date_str = start_date.strftime('%Y-%m-%d')
    end_date_str = end_date.strftime('%Y-%m-%d')

    for symbol in symbols:
        df = data_fetcher.fetch_historical_data(symbol, start_date_str, end_date_str)
        if not df.empty:
            all_data[symbol] = df
    return all_data
