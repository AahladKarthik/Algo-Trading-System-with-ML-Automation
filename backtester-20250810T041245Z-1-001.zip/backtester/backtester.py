# backtester/backtester.py

import pandas as pd
import logging
from strategy.trading_strategy import TradingStrategy

logger = logging.getLogger(__name__)

class Backtester:
    def __init__(self):
        self.strategy = TradingStrategy()
        self.trade_log = [] # To store details of each trade

    def run_backtest(self, symbol: str, historical_data: pd.DataFrame) -> dict:
        """
        Runs a backtest on the given historical data for a symbol.
        Simulates trades based on signals and calculates P&L.
        Parameters:
            symbol (str): Stock ticker symbol.
            historical_data (pd.DataFrame): DataFrame with historical OHLCV data.
        Returns:
            dict: Dictionary containing backtest summary (initial/final capital, total P&L)
                  and the detailed trade log. Returns empty dict if backtest cannot run.
        """
        if historical_data.empty:
            logger.warning(f"No historical data provided for backtesting {symbol}.")
            return {}

        df = historical_data.copy()
        df = self.strategy.generate_signals(df)

        # Filter out NaN rows that resulted from indicator calculations for cleaner iteration
        df.dropna(subset=['RSI', 'Signal', 'Position'], inplace=True)
        if df.empty:
            logger.warning(f"Data for {symbol} became empty after dropping NaNs for signals. Cannot backtest.")
            return {}

        initial_capital = 100000 # Example initial capital
        current_capital = initial_capital
        position_open = False
        buy_price = 0
        shares_held = 0

        # Reset trade_log for each backtest run
        self.trade_log = []

        for i in range(len(df)):
            date = df.index[i]
            close_price = df['Close'].iloc[i]
            signal = df['Signal'].iloc[i]
            current_position_status = df['Position'].iloc[i] # Current position from strategy

            # Execute buy trade
            if signal == 1 and not position_open: # Buy signal and no open position
                shares_to_buy = int(current_capital / close_price) # Buy as many shares as possible
                if shares_to_buy > 0:
                    buy_price = close_price
                    shares_held = shares_to_buy
                    current_capital -= (shares_held * buy_price) # Deduct cost
                    position_open = True
                    self.trade_log.append({
                        'Symbol': symbol,
                        'Date': date.strftime('%Y-%m-%d'),
                        'Type': 'BUY',
                        'Price': round(buy_price, 2),
                        'Shares': shares_held,
                        'Capital_After_Trade': round(current_capital, 2),
                        'P&L': 0.0 # P&L is realized on sell
                    })
                    logger.info(f"{symbol} - {date.strftime('%Y-%m-%d')}: BUY at {buy_price:.2f} (Shares: {shares_held})")

            # Execute sell trade
            elif signal == -1 and position_open: # Sell signal and there is an open position
                sell_price = close_price
                pnl = (sell_price - buy_price) * shares_held
                current_capital += (shares_held * sell_price) # Add proceeds
                position_open = False
                self.trade_log.append({
                    'Symbol': symbol,
                    'Date': date.strftime('%Y-%m-%d'),
                    'Type': 'SELL',
                    'Price': round(sell_price, 2),
                    'Shares': shares_held,
                    'Capital_After_Trade': round(current_capital, 2),
                    'P&L': round(pnl, 2)
                })
                logger.info(f"{symbol} - {date.strftime('%Y-%m-%d')}: SELL at {sell_price:.2f} (P&L: {pnl:.2f})")
                buy_price = 0 # Reset buy price
                shares_held = 0 # Reset shares held

        # If a position is still open at the end of the backtest, close it forcibly
        if position_open:
            sell_price = df['Close'].iloc[-1]
            pnl = (sell_price - buy_price) * shares_held
            current_capital += (shares_held * sell_price)
            self.trade_log.append({
                'Symbol': symbol,
                'Date': df.index[-1].strftime('%Y-%m-%d'),
                'Type': 'SELL (Forced Exit)', # Indicate a forced exit at end of backtest period
                'Price': round(sell_price, 2),
                'Shares': shares_held,
                'Capital_After_Trade': round(current_capital, 2),
                'P&L': round(pnl, 2)
            })
            logger.info(f"{symbol} - Forced SELL at {sell_price:.2f} (P&L: {pnl:.2f}) at end of backtest.")

        total_pnl = current_capital - initial_capital
        logger.info(f"Backtest for {symbol} completed. Total P&L: {total_pnl:.2f}")

        return {
            'symbol': symbol,
            'initial_capital': initial_capital,
            'final_capital': current_capital,
            'total_pnl': total_pnl,
            'trade_log': pd.DataFrame(self.trade_log) # Convert to DataFrame for easier handling
        }
