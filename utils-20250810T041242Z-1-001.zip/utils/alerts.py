# utils/alerts.py

import requests
import logging
from config import settings # Import settings module directly

logger = logging.getLogger(__name__)

def send_telegram_message(message: str):
    """
    Sends a message to a specified Telegram chat.
    Requires TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID from config/settings.py.
    Parameters:
        message (str): The text message to send.
    """
    try:
        bot_token = settings.TELEGRAM_BOT_TOKEN
        chat_id = settings.TELEGRAM_CHAT_ID
    except AttributeError:
        logger.error("Telegram bot token or chat ID not found in settings.py. Skipping Telegram alert.")
        return

    if not bot_token or not chat_id:
        logger.warning("Telegram BOT_TOKEN or CHAT_ID is not configured. Skipping alert.")
        return

    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": message,
        "parse_mode": "Markdown" # Allows basic markdown formatting in message
    }
    try:
        response = requests.post(url, json=payload)
        response.raise_for_status() # Raise an HTTPError for bad responses (4xx or 5xx)
        logger.info("Telegram message sent successfully.")
    except requests.exceptions.RequestException as e:
        logger.error(f"Error sending Telegram message: {e}")
