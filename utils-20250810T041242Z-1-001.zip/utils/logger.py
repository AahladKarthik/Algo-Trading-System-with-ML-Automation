# utils/logger.py

import logging
import os
from datetime import datetime

def setup_logging():
    """Configures logging for the application."""
    # Adjusted log_dir to be within your mounted Google Drive project structure.
    log_dir = '/content/drive/MyDrive/algo_trading_prototype/logs'
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    log_file = os.path.join(log_dir, f"algo_trading_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")

    logging.basicConfig(
        level=logging.INFO, # Log INFO, WARNING, ERROR, CRITICAL messages
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file), # Log to a file
            logging.StreamHandler()        # Also print to console
        ]
    )
    # Suppressing verbose logging from libraries to keep console clean
    logging.getLogger('requests').setLevel(logging.WARNING)
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('yfinance').setLevel(logging.WARNING)
    logging.getLogger('gspread').setLevel(logging.WARNING)
