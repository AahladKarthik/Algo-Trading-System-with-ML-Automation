# sheets/google_sheets_manager.py
import gspread
import pandas as pd
import logging
import os
from config import settings # Make sure settings.TELEGRAM_ALERTS_WORKSHEET_NAME is defined here

logger = logging.getLogger(__name__)

class GoogleSheetsManager:
    def __init__(self):
        self.spreadsheet = None
        try:
            credentials_path = "/content/drive/MyDrive/algo_trading_prototype/credentials.json"

            if not os.path.exists(credentials_path):
                logger.error(f"FATAL: credentials.json NOT FOUND at {credentials_path}")
                raise FileNotFoundError(f"credentials.json not found at {credentials_path}")

            logger.info(f"Attempting to load service account from: {credentials_path}")
            gc_temp = gspread.service_account(filename=credentials_path)

            if not isinstance(gc_temp, gspread.Client):
                logger.error(f"FATAL: gspread.service_account did NOT return a Client object. Type received: {type(gc_temp)}")
                raise TypeError("gspread.service_account did not return a gspread.Client object.")
            self.gc = gc_temp

            logger.info("gspread service account client created successfully.")

            self.spreadsheet = self.gc.open_by_id(settings.GOOGLE_SHEET_ID)
            logger.info(f"Successfully connected to Google Sheet: {self.spreadsheet.title}")

        except FileNotFoundError as e:
            logger.error(f"Error: {e}\nPlease ensure your 'credentials.json' is correctly placed and named.")
            self.spreadsheet = None
        except gspread.exceptions.SpreadsheetNotFound:
            logger.error(f"Google Sheet with ID '{settings.GOOGLE_SHEET_ID}' not found or you don't have access. "
                         f"Please check the ID and ensure it's shared with your service account email.")
            self.spreadsheet = None
        except Exception as e: # Catch all other exceptions
            logger.error(f"General error connecting to Google Sheets: {e}")
            logger.error(f"Please ensure:\n"
                         f"1. Google Sheets API is enabled in your GCP project.\n"
                         f"2. The Google Sheet (ID: {settings.GOOGLE_SHEET_ID}) is shared with the service account email (found in 'credentials.json').")
            self.spreadsheet = None

    def get_worksheet(self, worksheet_name: str):
        if self.spreadsheet:
            try:
                return self.spreadsheet.worksheet(worksheet_name)
            except gspread.exceptions.WorksheetNotFound:
                logger.error(f"Worksheet '{worksheet_name}' not found in the Google Sheet.")
                return None
        return None

    def read_data(self, worksheet_name: str):
        worksheet = self.get_worksheet(worksheet_name)
        if worksheet:
            try:
                data = worksheet.get_all_values()
                if not data:
                    return pd.DataFrame()
                df = pd.DataFrame(data[1:], columns=data[0])
                return df
            except Exception as e:
                logger.error(f"Error reading data from worksheet '{worksheet_name}': {e}")
        return pd.DataFrame()

    def write_data(self, worksheet_name: str, df: pd.DataFrame, clear_existing: bool = True):
        worksheet = self.get_worksheet(worksheet_name)
        if worksheet:
            try:
                if clear_existing:
                    worksheet.clear()
                # Prepare data including headers
                data_to_write = [df.columns.values.tolist()] + df.values.tolist()
                worksheet.update(data_to_write)
                logger.info(f"Successfully wrote data to worksheet '{worksheet_name}'.")
                return True
            except Exception as e:
                logger.error(f"Error writing data to worksheet '{worksheet_name}': {e}")
        return False

    def update_summary_pnl(self, pnl_results: dict):
        """
        Updates the 'Summary PnL' sheet with the P&L for each symbol.
        Parameters:
            pnl_results (dict): A dictionary with symbol as key and P&L as value.
        """
        if not self.spreadsheet:
            logger.warning("Google Sheets connection not established. Cannot update summary P&L.")
            return

        worksheet_name = settings.GOOGLE_SHEET_PNL_WORKSHEET_NAME # This should be 'Summary PnL'
        try:
            worksheet = self.spreadsheet.worksheet(worksheet_name)
        except gspread.exceptions.WorksheetNotFound:
            logger.warning(f"Worksheet '{worksheet_name}' not found. Creating it...")
            worksheet = self.spreadsheet.add_worksheet(title=worksheet_name, rows="100", cols="20")
            # Add headers after creating
            worksheet.update('A1', [['Symbol', 'Total PnL']])
            logger.info(f"Worksheet '{worksheet_name}' created successfully.")

        try:
            # Prepare data for update
            data_to_write = [['Symbol', 'Total PnL']]
            for symbol, pnl in pnl_results.items():
                data_to_write.append([symbol, pnl])

            # Clear existing data and update. Starting from A1 includes headers.
            worksheet.update('A1', data_to_write)
            logger.info(f"Successfully updated summary P&L in Google Sheet '{worksheet_name}'.")
        except Exception as e:
            logger.error(f"Error updating summary P&L in Google Sheet '{worksheet_name}': {e}")

    # --- ADD THIS NEW METHOD: get_signal_alerts ---
    def get_signal_alerts(self, symbol: str, date: str, signal_type: str, current_price: float) -> str:
        """
        Reads alert configurations from the 'Alerts' worksheet and generates an alert message
        if conditions are met.
        Parameters:
            symbol (str): The stock symbol.
            date (str): Current date (YYYY-MM-DD).
            signal_type (str): The generated trading signal (e.g., 'BUY', 'SELL', 'HOLD').
            current_price (float): The current closing price of the stock.
        Returns:
            str: An alert message if conditions are met, otherwise an empty string.
        """
        if not self.spreadsheet:
            logger.warning("Google Sheets connection not established. Cannot fetch alert configurations.")
            return ""

        alert_worksheet_name = settings.TELEGRAM_ALERTS_WORKSHEET_NAME # Assumed to be 'Alerts'
        try:
            alerts_df = self.read_data(alert_worksheet_name)
            if alerts_df.empty:
                logger.info(f"No alert configurations found in '{alert_worksheet_name}' worksheet.")
                return ""

            # Ensure columns are as expected and convert numeric types
            required_cols = ['Symbol', 'SignalType', 'PriceThreshold', 'Direction', 'Enabled']
            if not all(col in alerts_df.columns for col in required_cols):
                logger.warning(f"Alerts worksheet '{alert_worksheet_name}' missing required columns. "
                               f"Expected: {required_cols}. Found: {alerts_df.columns.tolist()}")
                return ""

            alerts_df['PriceThreshold'] = pd.to_numeric(alerts_df['PriceThreshold'], errors='coerce')
            alerts_df['Enabled'] = alerts_df['Enabled'].astype(str).str.lower().str.strip() == 'true'

            alert_message = ""
            # Filter for enabled alerts relevant to the current symbol
            relevant_alerts = alerts_df[(alerts_df['Symbol'] == symbol) & (alerts_df['Enabled'])]

            for _, row in relevant_alerts.iterrows():
                alert_signal = row['SignalType'].strip().upper()
                price_threshold = row['PriceThreshold']
                direction = row['Direction'].strip().lower() # 'above' or 'below'

                # Check for signal match
                if signal_type.upper() == alert_signal:
                    # Check for price threshold conditions (if PriceThreshold is not NaN)
                    price_condition_met = False
                    if pd.notna(price_threshold):
                        if direction == 'above' and current_price > price_threshold:
                            price_condition_met = True
                        elif direction == 'below' and current_price < price_threshold:
                            price_condition_met = True
                        elif direction == 'any': # Alert on signal regardless of price threshold if 'any' is specified
                             price_condition_met = True
                    else: # If no price threshold, then signal alone is enough
                        price_condition_met = True

                    if price_condition_met:
                        alert_message += (
                            f"🔔 ALERT for {symbol} on {date}:\n"
                            f"Signal: {signal_type.upper()}\n"
                            f"Current Price: {current_price:.2f}\n"
                        )
                        if pd.notna(price_threshold):
                             alert_message += f"Threshold: {price_threshold:.2f} ({direction})\n"
                        alert_message += "--- Sent by Algo-Trading Prototype ---\n\n"

            return alert_message.strip() # Remove trailing newlines/spaces

        except Exception as e:
            logger.error(f"Error fetching or processing signal alerts from Google Sheet: {e}")
            return ""
