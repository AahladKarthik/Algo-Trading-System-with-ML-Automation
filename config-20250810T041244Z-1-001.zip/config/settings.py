# config/settings.py

# Stock Data API (using yfinance)
# No API key is needed for basic yfinance usage
STOCK_SYMBOLS = ["RELIANCE.NS", "TCS.NS", "HDFCBANK.NS"] # Three NIFTY 50 stocks for NSE.

# Google Sheets Configuration
GOOGLE_SHEET_ID = '1W8nP1H7oIKwdy7m5dGii0lZcf_cKxn0mPSdzhAddm80' # Replace with your actual Google Sheet ID
GOOGLE_SHEET_TRADELOG_WORKSHEET_NAME = 'TradeLog'
GOOGLE_SHEET_PNL_WORKSHEET_NAME = 'Summary PnL'
TELEGRAM_ALERTS_WORKSHEET_NAME = 'Alerts'

# Telegram Configuration
TELEGRAM_BOT_TOKEN = 'YOUR_BOT_TOKEN' # Replace with your Telegram Bot Token
TELEGRAM_CHAT_ID = 'YOUR_CHAT_ID'     # Replace with your Telegram Chat ID

# Google Sheets
GOOGLE_SHEET_ID = "1W8nP1H7oIKwdy7m5dGii0lZcf_cKxn0mPSdzhAddm80"
TRADE_LOG_SHEET_NAME = "Trade Log"
SUMMARY_PL_SHEET_NAME = "Summary P&L"
WIN_RATIO_SHEET_NAME = "Win Ratio"

# Strategy Parameters
RSI_PERIOD = 14
RSI_BUY_THRESHOLD = 30
SHORT_MA_PERIOD = 20 # 20-Day Moving Average
LONG_MA_PERIOD = 50  # 50-Day Moving Average

# Backtesting Parameters
BACKTEST_DURATION_MONTHS = 6

# ML Model Parameters
FEATURES = ['RSI', 'MACD', 'Volume', 'Close'] # Features for ML model
TARGET = 'Next_Day_Movement' # Targets for ML model

# Telegram Alerts (Bonus)
TELEGRAM_BOT_TOKEN = "8144019769:AAF-f7tW-XV9URIgJAAFyQgNtE0Tce0naXw"
TELEGRAM_CHAT_ID = "1463467106"
